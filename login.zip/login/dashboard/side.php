
<nav>
    <div class="logo">
        <div class="logos">
           <img src="\test\finance\img\logo.png">
           <span class="town">Towntech Innvation</span>
        </div>
        <i class="fa-solid fa-times closed"></i>
    </div>
    <ul>
        <div class="ava">
           <img class="avatar big" name="old_file" src="../uploads/<?php// echo $fetch_username["image_profile"] ?>">
            <div class="user">
                 <p><?php echo $_SESSION["email"];?></p>
             </div> 
        </div>
        <span class="opac">Main</span>
        <li>
            <a href="../dashboard/dash.php">
                <span class="icon"><i class="fa-solid fa-cube"></i></span>
                <span class="text">Dashboard</span>
            </a>
        </li>
    </ul>
</nav>


